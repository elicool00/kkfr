<footer class="main-footer">
    <div class="float-right d-none d-sm-block">
      <b>Version</b> 1.0
    </div>
    <strong>Copyright &copy; 2022 <a href="https://github.com/Elh-Ayoub">El-Haddadi Ayoub</a>.</strong> All rights reserved.
</footer>