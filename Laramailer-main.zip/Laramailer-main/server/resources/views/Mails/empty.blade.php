{!! $view !!}
